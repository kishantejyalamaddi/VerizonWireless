import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable()
export class CryptoService {
  getCryptoUrl: string;

  constructor(private http: HttpClient) { 
    this.getCryptoUrl = 'http://localhost:8080/crypto/'; 
  }

  getData(): any {
    return this.http.get(this.getCryptoUrl);
  }
}
