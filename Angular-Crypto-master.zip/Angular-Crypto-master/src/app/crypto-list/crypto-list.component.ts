import { Component, OnInit } from '@angular/core';
import {MatDialog, MatTableDataSource} from '@angular/material';
import { Base } from '../base-controller';
import {CryptoService} from './crypto.service';
import { DialogService } from "../dialog/dialog.service";
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-user-list',
  templateUrl: './crypto-list.component.html',
  styleUrls: ['./crypto-list.component.css']
})
export class CryptoListComponent extends Base implements OnInit {
  data: any;
  usertable: any;
  columns: any;
  constructor(private dataService: CryptoService, private dialogService: DialogService, public dialog: MatDialog) { 
    super();
  }


  ngOnInit() {
    this.getData();
    this.columns = ['name', 'symbol', 'price', 'getdetails'];
  }

  applyFilter(filterValue: string) {
    this.usertable.filter = filterValue.trim().toLowerCase();
  }

  getData(): void {
    this.isLoading = true;
    this.noData = false;
    this.errorMsg = '';
    this.dataService.getData().subscribe((data) => 
          this.getDataDone(data),
        (err) => this.getDataFail(err));
  }

  getRecord(name)
  {
    const dialogRef = this.dialog.open(DialogComponent, {
      data: name,
      width: '40%'
    });
  }

  getDataDone(users) {
    this.isLoading = false;
    this.data = users.data.coins; // Users is the JSON response object
    this.data = users.data.coins;
    this.usertable = new MatTableDataSource(this.data);
    if (!users.data.coins.length) {
      this.noData = true;
    }
  }

  getDataFail(err) {
    this.isLoading = false;
    this.errorMsg = 'Unable to retrieve data';
  }

  onRefresh() {
    this.usertable = new MatTableDataSource([]); // to Emulate a refresh look... UI wise
    this.getData();
  }
}
