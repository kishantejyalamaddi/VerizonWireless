import { Injectable } from '@angular/core';
// import { environment } from '../environments/environment';

@Injectable()
export class AppContext {

    // server: string = 'http://localhost:12128/api/';
    // server: string = environment.apiUrl;
    // selectedEnv: number;
    // isLoggedIn: boolean = false;
    // session: string;
    // isSuperUser: boolean = false;
    // isAdmin: boolean = false;
    // userType: number;
    // username: string;
}
