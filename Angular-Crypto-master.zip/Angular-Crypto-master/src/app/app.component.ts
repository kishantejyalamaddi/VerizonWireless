import { Component } from '@angular/core';
import { AppContext } from './app-context';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //Head toolbar text
  title = 'List Page - All';
}
