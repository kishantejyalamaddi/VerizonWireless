import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AppContext} from './app-context';
import {CryptoService} from './crypto-list/crypto.service';
import {HttpClientModule} from '@angular/common/http';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CryptoListComponent } from './crypto-list/crypto-list.component';
import { ToolbarComponent } from './toolbar/toolbar.component';
import {
  MatMenuModule,
  MatIconModule,
  MatToolbarModule,
  MatTableModule,
  MatProgressSpinnerModule,
  MatTooltipModule,
  MatFormFieldModule,
  MatInputModule,
  MatButtonModule,
  MatSlideToggleModule,
  MatDialogModule,
  MatDatepickerModule,
  MatNativeDateModule
} from '@angular/material';
import { DialogComponent } from './dialog/dialog.component';
import { DialogService } from './dialog/dialog.service';

@NgModule({
  declarations: [
    AppComponent,
    CryptoListComponent,
    ToolbarComponent,
    DialogComponent
  ],
  imports: [
  BrowserModule,
  MatTooltipModule,
  MatProgressSpinnerModule,
   MatMenuModule,
   MatIconModule,
   MatToolbarModule,
   HttpClientModule,
   MatTableModule,
   NoopAnimationsModule,
   FormsModule,
   ReactiveFormsModule,
   MatFormFieldModule,
   MatInputModule,
   MatButtonModule,
   MatSlideToggleModule,
   MatDialogModule,
   MatDatepickerModule,
   MatNativeDateModule
  ],
  providers: [AppContext, CryptoService, DialogService],
  entryComponents: [DialogComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
