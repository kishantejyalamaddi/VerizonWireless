// import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
export class Base {
    isLoading: boolean = false;
    noData: boolean = false;
    errorMsg: string = '';
    constructor() {

    }    
}
